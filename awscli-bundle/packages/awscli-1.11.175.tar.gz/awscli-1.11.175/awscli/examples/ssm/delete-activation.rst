**To delete an activation**

This example deletes an activation. There is no output if the command succeeds.

Command::

  aws ssm delete-activation --activation-id "bcf6faa8-83fd-419e-9534-96ad14131eb7"
